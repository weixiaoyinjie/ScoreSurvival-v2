const assert=require('node:assert/strict');const E=require('../app/src/main/assets/engine.js');
let t=[{k:'2-0',amount:2500,odd:7.5,role:'主单'},{k:'2-0',amount:2500,odd:7.5,role:'主单'},{k:'1-0',amount:2500,odd:6,role:'保单'},{k:'1-1',amount:1000,odd:7,role:'保单'}];
assert.equal(E.keys.length,25);assert.equal(E.node(t,0,0).count,4);assert.equal(E.node(t,1,0).count,4);assert.equal(E.node(t,0,1).count,1);assert.equal(E.node(t,2,0).count,2);assert.equal(E.node(t,1,1).count,1);assert.equal(E.node(t,2,1).count,0);assert.equal(E.node(t,0,2).count,0);assert.equal(E.node(t,5,0).count,0);
let book={bets:[{name:'Correct Score',values:[{value:'1:0',odd:'6.00'}]},{name:'Correct Score - First Half',values:[{value:'1:0',odd:'3.50'}]},{name:'Correct Score - Second Half',values:[{value:'1:0',odd:'4.00'}]}]};assert.deepEqual(E.parseOdds(book,'HT'),{'1-0':3.5});assert.deepEqual(E.parseOdds(book,'FT'),{'1-0':6});
for(let i=0;i<100;i++){let d=E.probs(.1+i/30,.2+i/40);assert.ok(Math.abs(Object.values(d.p).reduce((a,b)=>a+b,0)+d.tail-1)<1e-10);let o=Object.fromEntries(E.keys.map((k,j)=>[k,2+(j*7+i)%60]));let cap=i*100;let p=E.plan(d.p,o,10000,cap);assert.ok(p.total<=10000+cap+1e-6);assert.ok(p.tickets.every(t=>t.amount*t.odd+1e-6>=p.total));assert.ok(p.tickets.every(t=>o[t.k]===t.odd));assert.ok(p.tickets.filter(t=>t.role==='主单').length===1);assert.ok(p.tickets.length<=25);}
console.log('PASS: 25节点、历史组合存活、赔率隔离、100组概率/预算/保本测试');
const arab=[{k:'3-0',amount:2500,odd:9.5},{k:'3-0',amount:2500,odd:9.5},{k:'2-0',amount:1500,odd:7},{k:'1-0',amount:1500,odd:7.5}];
let ar=E.pathRisk(arab);assert.equal(ar.distinct,3);assert.equal(ar.awayFirst,0);assert.equal(ar.breakDepth,1);assert.equal(E.node(arab,1,1).count,0);assert.equal(E.node(arab,1,0).amount,8000);
let dd=E.probs(1.5,.8);assert.equal(E.guardedPlan(dd.p,{'1-0':7.5,'2-0':7,'3-0':9.5},5000,3000,'3-0'),null);
let count=0;for(let i=0;i<100;i++){let o=Object.fromEntries(E.keys.map((k,j)=>[k,2+(j*7+i)%60]));let cap=i*100;let g=E.guardedPlan(dd.p,o,10000,cap);if(!g)continue;count++;assert.ok(g.total<=10000+cap+1e-6);assert.ok(g.tickets.every(t=>t.amount*t.odd+1e-6>=g.total));assert.ok(g.risk.homeFirst>=2&&g.risk.awayFirst>=2);assert.ok(g.risk.second.every(n=>n>0));assert.ok(g.risk.breakDepth>=3);}
assert.ok(count>0);console.log('PASS: Al Arabi复盘、单向赔率拒绝、100组多路径预算校验；可行组合 '+count);
const allOdds=Object.fromEntries(E.keys.map((k,j)=>[k,5+j*2]));
let audit=E.compareMains(dd.p,allOdds,10000,10000,'');assert.ok(audit.plan);assert.equal(audit.rows.length,25);assert.ok(!audit.selected.low);assert.ok(audit.plan.risk.second.every(n=>n>0));
assert.equal(E.compareMains(dd.p,{'1-0':7.5,'2-0':7,'3-0':9.5},5000,3000,'3-0').plan,null);
assert.equal(E.compareMains(dd.p,allOdds,10000,10000,'5-0').plan,null);
assert.ok(E.compareMains(dd.p,allOdds,10000,10000,'3-0').selected.k==='3-0');
console.log('PASS: 主单全候选审核、单向拒绝、手动指定不静默替换');
