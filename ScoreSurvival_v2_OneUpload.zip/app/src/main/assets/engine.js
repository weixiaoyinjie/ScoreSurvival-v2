'use strict';
const Engine=(()=>{
const keys=Array.from({length:25},(_,i)=>`${Math.floor(i/5)}-${i%5}`);
const parts=k=>k.split('-').map(Number);
const valid=(k,h,a)=>{let [x,y]=parts(k);return x>=h&&y>=a;};
const oddsValid=o=>Number.isFinite(o)&&o>1&&o<=10000;
function parseOdds(book,mode){let out={};for(const bet of book?.bets||[]){let n=String(bet.name||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();let correct=/(correct score|exact score)/.test(n);let ht=/(half time|halftime|first half|1st half|1st period|half 1|1h)/.test(n);let other=/(second half|2nd half|half 2|2h|extra time|penalt|both halves|half time full time|halftime fulltime)/.test(n);if(!correct||other||(mode==='HT')!==ht)continue;if(mode==='FT'&&!/^(correct score|exact score|full time correct score|fulltime correct score|correct score full time|correct score fulltime|exact score full time)$/.test(n))continue;for(const v of bet.values||[]){let m=String(v.value).trim().match(/^(\d+)\s*[-:]\s*(\d+)$/);let o=Number(v.odd);if(m&&oddsValid(o)){let k=Number(m[1])+'-'+Number(m[2]);if(keys.includes(k))out[k]=o;}}}return out;}
function history(rows,id,mode,venue){let r=[];for(const f of rows||[]){if(!['FT','AET','PEN'].includes(f.fixture?.status?.short))continue;let home=f.teams?.home?.id===id;if(!home&&f.teams?.away?.id!==id)continue;if(venue==='home'&&!home||venue==='away'&&home)continue;let s=mode==='HT'?f.score?.halftime:f.score?.fulltime;if(!s||!Number.isInteger(s.home)||!Number.isInteger(s.away))continue;let gf=home?s.home:s.away,ga=home?s.away:s.home;r.push({gf,ga,venue:home?'H':'A',date:f.fixture.date,opponent:home?f.teams.away.name:f.teams.home.name});}return r;}
function stat(rows,base){let n=rows.length;let mean=k=> (rows.reduce((s,r)=>s+r[k],0)+3*base)/(n+3);return {n,gf:mean('gf'),ga:mean('ga'),w:rows.filter(r=>r.gf>r.ga).length,d:rows.filter(r=>r.gf===r.ga).length,l:rows.filter(r=>r.gf<r.ga).length,zero:rows.filter(r=>r.gf===0).length,one:rows.filter(r=>r.gf===1).length,multi:rows.filter(r=>r.gf>=2).length};}
function means(home,away,mode){let b=mode==='HT'?.55:1.25;let blend=(all,v,k)=>{let a=stat(all,b),s=stat(v,b),w=Math.min(.75,v.length/(v.length+4));return a[k]*(1-w)+s[k]*w;};return {h:Math.max(.05,(blend(home,home.filter(x=>x.venue==='H'),'gf')+blend(away,away.filter(x=>x.venue==='A'),'ga'))/2),a:Math.max(.05,(blend(away,away.filter(x=>x.venue==='A'),'gf')+blend(home,home.filter(x=>x.venue==='H'),'ga'))/2)};}
function probs(h,a){let poisson=(l,k)=>{let v=Math.exp(-l);for(let i=1;i<=k;i++)v*=l/i;return v;};let p={};for(let k of keys){let [x,y]=parts(k);p[k]=poisson(h,x)*poisson(a,y);}return {p,tail:Math.max(0,1-Object.values(p).reduce((a,b)=>a+b,0))};}
function plan(p,odds,main,cap,manual){if(!Number.isFinite(main)||main<=0||!Number.isFinite(cap)||cap<0)throw Error('金额无效');let available=keys.filter(k=>oddsValid(odds[k]));if(!available.length)return null;available.sort((a,b)=>p[b]-p[a]||odds[b]-odds[a]);let m=manual&&available.includes(manual)?manual:available[0];let maxTotal=main+cap;let maxInv=1-main/Math.min(maxTotal,main*odds[m]);let candidates=available.filter(k=>k!==m).sort((a,b)=>p[b]*odds[b]-p[a]*odds[a]);let states=[{inv:0,prob:0,list:[]}];for(let k of candidates){let add=1/odds[k];let next=states.concat(states.filter(s=>s.inv+add<=maxInv+1e-12).map(s=>({inv:s.inv+add,prob:s.prob+p[k],list:s.list.concat(k)})));next.sort((a,b)=>a.inv-b.inv||b.prob-a.prob);let best=-1;states=[];for(let s of next){if(s.prob>best+1e-12){states.push(s);best=s.prob;}}if(states.length>3000)states=states.filter((_,i)=>i===states.length-1||i%Math.ceil(states.length/2500)===0);}
let chosen=states.sort((a,b)=>b.prob-a.prob||a.inv-b.inv)[0];let total=main/(1-chosen.inv);let tickets=[{k:m,amount:main,odd:odds[m],role:'主单'},...chosen.list.map(k=>({k,amount:Math.ceil(total/odds[k]*100)/100,odd:odds[k],role:'保单'}))];let spent=()=>tickets.reduce((s,t)=>s+t.amount,0);for(let i=0;i<100;i++){let sum=spent();let changed=false;for(let t of tickets.slice(1)){if(t.amount*t.odd+1e-8<sum){t.amount=Math.ceil(sum/t.odd*100-1e-9)/100;changed=true;}}if(!changed)break;}let current=spent();if(current>maxTotal+1e-8||current>main*odds[m]+1e-8||tickets.some(t=>t.amount*t.odd+1e-7<current)){tickets=[tickets[0]];} // rounding safety
let sum=spent();let covered=tickets.reduce((s,t)=>s+p[t.k],0);let ev=tickets.reduce((s,t)=>s+p[t.k]*t.amount*t.odd,0)-sum;
return {tickets,total:sum,covered,ev,main:m,cap,mainAmount:main};}
function node(tickets,h,a){let alive=tickets.filter(t=>valid(t.k,h,a));let exact=alive.filter(t=>t.k===`${h}-${a}`);return {count:alive.length,amount:alive.reduce((s,t)=>s+t.amount,0),exact:exact.reduce((s,t)=>s+t.amount*t.odd,0),exactAmount:exact.reduce((s,t)=>s+t.amount,0),role:exact.some(t=>t.role==='主单')?'主':exact.length?'保':''};}
// Count distinct terminal scores, not duplicated tickets. All counts are structural, not probabilities.
function pathRisk(tickets){
 const distinct=[...new Set(tickets.map(t=>t.k))];
 const at=(h,a)=>distinct.filter(k=>valid(k,h,a)).length;
 const layers=Array.from({length:9},(_,d)=>{let states=keys.filter(k=>parts(k).reduce((x,y)=>x+y,0)===d);return {depth:d,alive:states.filter(k=>at(...parts(k))>0).length,total:states.length};});
 const dead=keys.filter(k=>at(...parts(k))===0).map(k=>parts(k).reduce((x,y)=>x+y,0));
 return {distinct:distinct.length,homeFirst:at(1,0),awayFirst:at(0,1),second:[at(2,0),at(1,1),at(0,2)],breakDepth:Math.min(5,...dead),layers};
}
// Search bounded Pareto frontiers separately for each structural coverage signature.
// Two distinct scores after either first goal and all depth-two states reachable by default.
function guardedPlan(p,odds,main,cap,manual,depth=2){
 if(!Number.isFinite(main)||main<=0||!Number.isFinite(cap)||cap<0)throw Error('金额无效');
 const avail=keys.filter(k=>oddsValid(odds[k])).sort((a,b)=>p[b]-p[a]);
 if(!avail.length)return null;
 if(manual&&!avail.includes(manual))return null;
 const m=manual||avail[0],maxTotal=Math.min(main+cap,main*odds[m]),limit=1-main/maxTotal;
 const sig=(k)=>{let [h,a]=parts(k);return {h:h>=1?1:0,a:a>=1?1:0,b:(h>=2?1:0)|(h>=1&&a>=1?2:0)|(a>=2?4:0)};};
 const add=(s,k,inv)=>{let q=sig(k);return {h:Math.min(2,s.h+q.h),a:Math.min(2,s.a+q.a),b:s.b|q.b,inv:s.inv+inv,prob:s.prob+(p[k]||0),list:s.list.concat(k)};};
 let states=[add({h:0,a:0,b:0,inv:0,prob:0,list:[]},m,0)];
 for(const k of avail.filter(k=>k!==m)){
  let next=states.concat(states.filter(s=>s.inv+1/odds[k]<=limit+1e-12).map(s=>add(s,k,1/odds[k]))),groups=new Map();
  for(let s of next){let id=s.h+','+s.a+','+s.b;if(!groups.has(id))groups.set(id,[]);groups.get(id).push(s);}
  states=[];for(let g of groups.values()){g.sort((a,b)=>a.inv-b.inv||b.prob-a.prob);let best=-1,front=[];for(let s of g)if(s.prob>best+1e-12){front.push(s);best=s.prob;}if(front.length>80){const last=front.length-1;front=Array.from({length:80},(_,i)=>front[Math.round(i*last/79)]);}states.push(...front);}
 }
 const feasible=states.filter(s=>s.h>=2&&s.a>=2&&(depth!==2||s.b===7)).sort((a,b)=>b.prob-a.prob||a.inv-b.inv);
 for(let s of feasible){
  let total=main/(1-s.inv),tickets=s.list.map((k,i)=>({k,odd:odds[k],amount:i?Math.ceil(total/odds[k]*100)/100:main,role:i?'保单':'主单'}));
  for(let i=0;i<100;i++){let sum=tickets.reduce((v,t)=>v+t.amount,0),changed=false;for(let t of tickets.slice(1)){if(t.amount*t.odd+1e-8<sum){t.amount=Math.ceil(sum/t.odd*100-1e-9)/100;changed=true;}}if(!changed)break;}
  let sum=tickets.reduce((v,t)=>v+t.amount,0);
  if(sum>maxTotal+1e-7||tickets.some(t=>t.amount*t.odd+1e-7<sum))continue;
  return {tickets,total:sum,covered:s.prob,ev:tickets.reduce((v,t)=>v+(p[t.k]||0)*t.amount*t.odd,0)-sum,main:m,cap,mainAmount:main,risk:pathRisk(tickets)};
 }
 return null;
}
// Candidate audit: compare complete portfolios, never select a main solely by price.
function compareMains(p,odds,main,cap,manual){
 const quoted=keys.filter(k=>oddsValid(odds[k])).sort((a,b)=>(p[b]||0)-(p[a]||0));
 const top=Math.max(0,...quoted.map(k=>p[k]||0));
 const rows=quoted.map(k=>{
   const probability=p[k]||0, [h,a]=parts(k);
   const g=guardedPlan(p,odds,main,cap,k);
   const low=probability<top*.35;
   // Heuristic, not calibrated: probability first, then portfolio breadth and cost.
   const score=g? .65*(top?probability/top:0)+.25*g.covered+.10*(cap?1-(g.total-main)/cap:1):null;
   return {k,probability,odd:odds[k],zero:h===0||a===0,multi:h>=3||a>=3,low,score,plan:g,reason:!g?'预算或赔率无法通过多路径与保本检查':low?'相对模型概率偏低，不自动作为主单':'通过结构检查；仍需验证概率与赔率'};
 });
 rows.sort((a,b)=>Number(!!b.plan&&!b.low)-Number(!!a.plan&&!a.low)||(b.score??-1)-(a.score??-1)||b.probability-a.probability);
 const selected=manual?rows.find(r=>r.k===manual):rows.find(r=>r.plan&&!r.low);
 return {plan:selected?.plan||null,rows,selected,top,manual:!!manual};
}
return {keys,parts,valid,parseOdds,history,stat,means,probs,plan,node,oddsValid,pathRisk,guardedPlan,compareMains};})();
if(typeof module!=='undefined')module.exports=Engine;
