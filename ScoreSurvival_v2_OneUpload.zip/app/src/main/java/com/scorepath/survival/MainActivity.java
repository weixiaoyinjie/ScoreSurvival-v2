package com.scorepath.survival;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.graphics.Color;
import android.view.View;
import android.view.WindowInsets;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService pool=Executors.newFixedThreadPool(3);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web=new WebView(this); web.setBackgroundColor(Color.rgb(15,20,25));
        web.setOnApplyWindowInsetsListener((v,insets)->{
            if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(i.left,i.top,i.right,i.bottom);}
            return insets;
        });
        setContentView(web);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}});
        web.addJavascriptInterface(new Bridge(),"Native");web.loadUrl("file:///android_asset/index.html");
    }
    private void done(String id, JSONObject result){runOnUiThread(()->web.evaluateJavascript("window.nativeResult("+JSONObject.quote(id)+","+result.toString()+")",null));}
    class Bridge {
        @JavascriptInterface public void request(String id,String kind,String path,String key,String body){pool.execute(()->{
            JSONObject result=new JSONObject();HttpURLConnection c=null;
            try{
                URL url;
                if(kind.equals("football")){
                    if(!path.matches("/(fixtures|odds|odds/bookmakers)(\\?[A-Za-z0-9%&=._+-]+)?"))throw new Exception("不支持的足球 API 路径");
                    url=new URL("https://v3.football.api-sports.io"+path);
                }else if(kind.equals("ai")){url=new URL("https://api.openai.com/v1/chat/completions");}else throw new Exception("不支持的服务");
                c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(20000);c.setReadTimeout(60000);c.setInstanceFollowRedirects(false);
                c.setRequestProperty("Accept","application/json");
                if(kind.equals("football"))c.setRequestProperty("x-apisports-key",key);
                else {c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
                int status=c.getResponseCode();InputStream stream=status>=200&&status<300?c.getInputStream():c.getErrorStream();
                if(stream==null)throw new Exception("HTTP "+status);ByteArrayOutputStream buffer=new ByteArrayOutputStream();try(InputStream input=stream){byte[] bytes=new byte[8192];int n;while((n=input.read(bytes))!=-1){buffer.write(bytes,0,n);if(buffer.size()>6000000)throw new Exception("响应过大");}}
                result.put("ok",status>=200&&status<300);result.put("status",status);result.put("body",buffer.toString("UTF-8"));
            }catch(Exception e){try{result.put("ok",false);result.put("body",e.getMessage()==null?"网络异常":e.getMessage());}catch(Exception ignored){}}
            finally{if(c!=null)c.disconnect();}done(id,result);
        });}
    }
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
